const dotenv = require("dotenv");
dotenv.config();

const express = require("express");
const cors = require("cors");
const axios = require("axios");
const admin = require("firebase-admin");
const fs = require("fs");

// ENV
const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET;
const VTPASS_API_KEY = process.env.VTPASS_API_KEY;
const VTPASS_SECRET_KEY = process.env.VTPASS_SECRET_KEY;
const FIREBASE_SERVICE_ACCOUNT_PATH =
  process.env.FIREBASE_SERVICE_ACCOUNT_PATH;

// Firebase init
if (!admin.apps.length) {
  const serviceAccount = JSON.parse(
    fs.readFileSync(FIREBASE_SERVICE_ACCOUNT_PATH, "utf8")
  );

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

const db = admin.firestore();

// ============================================================
// Route modules
// ============================================================
const electricityRoutes = require("./src/routes/electricity.routes.js");
const airtimeRoutes = require("./src/routes/airtime.routes.js");
const dataRoutes = require("./src/routes/data.routes.js");
const walletRoutes = require("./src/routes/wallet.routes.js");
const transactionRoutes = require("./src/routes/transaction.routes");
const transferRoutes = require("./src/routes/transfer.routes");
const dvaRoutes = require("./src/routes/dva.routes");
const cableRoutes = require("./src/routes/cable.routes.js");
const bettingRoutes = require("./src/routes/betting.routes.js");
const userServicesRoutes = require("./src/routes/userServices.routes");
const analyticsRoutes = require("./src/routes/analytics.routes");
const authRoutes = require("./src/routes/auth.routes.js");
const statementRoute = require("./src/routes/statement");
const authMiddleware = require("./src/middleware/authMiddleware");
const giftcardRoutes = require("./src/routes/giftcard.routes");
const monnifyRoutes = require("./src/routes/monnify.routes");
const { monnifyWebhook } = require("./src/webhooks/monnify.webhook");
const identityRoutes = require("./src/routes/identity.routes");
const contactRoutes = require("./src/routes/contact.js");
const profileRoutes = require("./src/routes/profile.routes.js");
const securityRoutes = require("./src/routes/security.routes.js");
const prestmitRoutes = require("./src/routes/prestmit.routes");
const prestmitSellRoutes = require("./src/routes/prestmit.sell.routes");
const bulkTransferRoutes = require("./src/routes/bulkTransfer.routes");
const depositRoutes = require("./src/routes/deposit.routes");
const monnifyBillsRoutes = require("./src/routes/monnifyBills.routes");
const foodRoutes = require("./src/routes/food.routes.js");
const foodChatRoutes = require("./src/routes/foodChat.routes.js");
const foodMerchantAdminRoutes = require("./src/routes/foodMerchantAdmin.routes.js");
const kycAdminRoutes = require("./src/routes/kycAdmin.routes.js");
const virtualAccountRoutes = require("./src/routes/virtualAccount.routes");
const { paystackWebhook } = require("./src/webhooks/paystack.webhook");
const clubkonnectProductsRoutes = require("./src/routes/clubkonnectProducts.routes");

// IMPORTANT:
// This is the actual Prestmit webhook handler.
// There is NO prestmit.webhook.routes.js file required.
const { prestmitWebhook } = require("./src/webhooks/prestmit.webhook");

// ============================================================
// App
// ============================================================
const app = express();

app.set("trust proxy", 1);

const PORT = process.env.PORT || 4000;

// ============================================================
// VTPASS base URL
// ============================================================
const VTPASS_BASE_URL =
  process.env.VTPASS_ENV === "sandbox"
    ? "https://sandbox.vtpass.com/api"
    : "https://vtpass.com/api";

// ============================================================
// Debug ENV (masked)
// ============================================================
const mask = (str) =>
  str
    ? str.substring(0, 3) + "***" + str.substring(str.length - 3)
    : "undefined";

console.log("VTPASS_API_KEY:", mask(VTPASS_API_KEY));
console.log("VTPASS_SECRET_KEY:", mask(VTPASS_SECRET_KEY));
console.log("VTPASS_ENV:", process.env.VTPASS_ENV);

// ============================================================
// Middleware
// ============================================================
app.use(
  cors({
    origin: [
      "http://localhost:5000",
      "http://127.0.0.1:5000",
      "http://172.23.8.53:5000",
      "http://localhost",
      "http://127.0.0.1",
    ],
    methods: [
      "GET",
      "HEAD",
      "POST",
      "PUT",
      "PATCH",
      "DELETE",
      "OPTIONS",
    ],
    allowedHeaders: [
      "Content-Type",
      "Authorization",
    ],
    credentials: true,
  })
);

// ============================================================
// Prestmit Webhook
// ============================================================
//
// IMPORTANT:
// Prestmit webhook signature verification requires the ORIGINAL
// raw request body.
//
// Therefore this route MUST be registered BEFORE:
//
//     app.use(express.json());
//
// Do not move it below express.json().
//
// Endpoint:
//
//     POST /api/prestmit/webhook
//
// ============================================================
app.post(
  "/api/prestmit/webhook",
  express.raw({
    type: "application/json",
    limit: "1mb",
  }),
  prestmitWebhook
);

// ============================================================
// Monnify Webhook
// ============================================================
//
// IMPORTANT:
// Monnify signature verification requires the ORIGINAL raw
// request body.
//
// Therefore this route MUST also be registered BEFORE:
//
//     app.use(express.json());
//
// Endpoint:
//
//     POST /api/monnify/webhook
//
// The raw Buffer is saved as req.rawBody.
// The same body is then parsed back into req.body so the
// existing Monnify webhook handler can process eventData,
// eventType, etc.
//
// ============================================================
app.post(
  "/api/monnify/webhook",
  express.raw({
    type: "application/json",
    limit: "1mb",
  }),
  (req, res, next) => {
    try {
      if (!Buffer.isBuffer(req.body)) {
        console.warn(
          "⚠️ Monnify webhook body was not received as a Buffer."
        );

        req.rawBody = null;

        return next();
      }

      // Preserve the exact original request body for
      // Monnify HMAC signature validation.
      req.rawBody = req.body;

      const rawBodyString = req.body.toString("utf8");

      if (!rawBodyString) {
        req.body = {};

        return next();
      }

      req.body = JSON.parse(rawBodyString);

      next();
    } catch (err) {
      console.error(
        "❌ Failed to parse Monnify webhook body:",
        err.message || err
      );

      return res.status(400).send("Invalid JSON payload");
    }
  },
  monnifyWebhook
);

// ============================================================
// Normal body parsing
// ============================================================
app.post(
  "/api/paystack/webhook",
  express.raw({ type: "application/json", limit: "1mb" }),
  paystackWebhook
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============================================================
// Health check
// ============================================================
app.get("/", (req, res) => {
  res.json({
    status: "ok",
    message: "UtilityHub backend running",
  });
});

// ============================================================
// Core routes
// ============================================================
app.use("/", transactionRoutes);
app.use("/", walletRoutes);
app.use("/", userServicesRoutes);
app.use("/", analyticsRoutes);

app.use("/auth", authRoutes);

app.use("/v1/statement", authMiddleware, statementRoute);

app.use("/api/giftcard", giftcardRoutes);

app.use("/api/virtual-account", virtualAccountRoutes);
app.use("/api/monnify", monnifyRoutes);
app.use("/api/deposits", depositRoutes);
app.use("/api/monnify/bills", monnifyBillsRoutes);

app.use("/api", identityRoutes);
app.use("/api", contactRoutes);
app.use("/api", profileRoutes);
app.use("/api", securityRoutes);
app.use("/api/admin", kycAdminRoutes);
app.use("/api/food", foodRoutes);
app.use("/api/food-admin", foodMerchantAdminRoutes);
app.use("/api/food-chat", foodChatRoutes);

// ============================================================
// Prestmit API routes
// ============================================================
app.use("/api/prestmit", prestmitRoutes);
app.use("/api/prestmit/sell", prestmitSellRoutes);

// ============================================================
// ClubKonnect / VTPass feature routes
// ============================================================
app.use("/api/electricity", electricityRoutes);
app.use("/api/airtime", airtimeRoutes);
app.use("/api/data", dataRoutes);
app.use("/api/cable", cableRoutes);
app.use("/api/betting", bettingRoutes);
app.use("/api/clubkonnect-products", clubkonnectProductsRoutes);

// ============================================================
// Transfers
// ============================================================
app.use("/api/transfer", transferRoutes);
app.use("/api/transfers", bulkTransferRoutes);

// ============================================================
// Paystack Dedicated Virtual Account routes
// ============================================================
app.use("/paystack", dvaRoutes);

// ============================================================
// Import cron job
// ============================================================
require("./src/jobs/requeryPendingTransactions");

// ============================================================
// Monnify Reserved-Account Deposit Monitor
// ============================================================
//
// TEMPORARILY DISABLED.
//
// We are testing the Monnify webhook as the primary deposit
// notification path. The monitor is NOT being deleted.
// It can be re-enabled later as a reconciliation/fallback
// mechanism after the webhook has been proven.
//
// ============================================================

// const {
//   startDepositMonitor,
// } = require("./src/jobs/deposit-monitor.job");

// startDepositMonitor();

// ============================================================
// Paystack: Initialize Transaction
// ============================================================
app.post("/paystack/initialize", async (req, res) => {
  try {
    const { email, amount, reference, userId } = req.body;

    if (!email || !amount || !userId) {
      return res.status(400).json({
        status: false,
        message: "Missing email, amount, or userId",
      });
    }

    const body = {
      email,
      amount, // already in kobo from frontend
      callback_url: `http://localhost:5000/payment-success.html?userId=${userId}`,
    };

    if (reference) {
      body.reference = reference;
    }

    const response = await axios.post(
      "https://api.paystack.co/transaction/initialize",
      body,
      {
        headers: {
          Authorization: `Bearer ${PAYSTACK_SECRET}`,
          "Content-Type": "application/json",
        },
      }
    );

    const data = response.data;

    if (!data?.status) {
      return res.status(400).json({
        status: false,
        message:
          data?.message || "Failed to initialize Paystack transaction",
        raw: data,
      });
    }

    return res.json({
      status: true,
      authorization_url: data.data.authorization_url,
      reference: data.data.reference,
    });
  } catch (err) {
    console.error(
      "Paystack initialize error:",
      err.message || err
    );

    return res.status(500).json({
      status: false,
      message: "Server error initializing transaction",
    });
  }
});

// ============================================================
// Paystack: Verify Transaction
// ============================================================
app.get("/verify/:ref", async (req, res) => {
  const ref = req.params.ref;
  const userId = req.query.userId;

  if (!ref) {
    return res.status(400).json({
      status: false,
      message: "Missing reference",
    });
  }

  try {
    const response = await axios.get(
      `https://api.paystack.co/transaction/verify/${ref}`,
      {
        headers: {
          Authorization: `Bearer ${PAYSTACK_SECRET}`,
          "Content-Type": "application/json",
        },
      }
    );

    const data = response.data;

    if (!data || !data.status || !data.data) {
      return res.status(400).json({
        status: false,
        message: data?.message || "Invalid Paystack response",
      });
    }

    const paystackStatus = data.data.status;
    const amountKobo = data.data.amount;
    const amountNaira = amountKobo / 100;

    // ========================================================
    // AUTO-DETECT FUNDING METHOD
    // ========================================================
    const channel = data.data.channel || "card";
    const method = channel === "bank" ? "bank" : "card";

    // ========================================================
    // APPLY FEE ENGINE
    // ========================================================
    const FeeEngine = require("./core/fees/fee_engine");

    const feeResult = FeeEngine.walletFunding(
      method,
      amountNaira
    );

    const userPays = feeResult.userPays;
    const fee = feeResult.fee;

    // ========================================================
    // CREDIT WALLET IF SUCCESSFUL
    // ========================================================
    if (paystackStatus === "success" && userId) {
      const walletRef = db.collection("wallets").doc(userId);
      const walletDoc = await walletRef.get();

      const prevBalance = Number(
        walletDoc.data()?.balance || 0
      );

      const newBalance = prevBalance + amountNaira;

      const creditTx = {
        id: ref,
        type: "credit",
        title: "Wallet Funding (Paystack)",
        amount: amountNaira,
        fee,
        totalDebited: userPays,
        timestamp: Date.now(),
        status: "success",
        provider: "paystack",
        channel: method,
      };

      await walletRef.set(
        {
          balance: newBalance,
          transactions:
            admin.firestore.FieldValue.arrayUnion(creditTx),
        },
        { merge: true }
      );
    }

    return res.json({
      status: true,
      data: {
        status: paystackStatus,
        amount: amountNaira,
        fee,
        totalDebited: userPays,
        method,
      },
    });
  } catch (err) {
    console.error(
      "Paystack verify error:",
      err.message || err
    );

    return res.status(500).json({
      status: false,
      message: "Server error verifying transaction",
    });
  }
});

// ============================================================
// Airtime Requery
// ============================================================
app.post("/api/airtime/requery", async (req, res) => {
  const { requestId } = req.body;

  const {
    requeryAirtime,
  } = require("./src/services/clubkonnectAirtime.service.js");

  const data = await requeryAirtime({ requestId });

  const status =
    data?.orderstatus ||
    data?.status ||
    data?.statuscode ||
    data?.data?.orderstatus ||
    data?.data?.status ||
    data?.data?.statuscode;

  const remark =
    data?.remark ||
    data?.orderremark ||
    data?.data?.remark ||
    data?.data?.orderremark ||
    "Airtime purchase processed";

  const wallets = await db.collection("wallets").get();

  let userId = null;
  let walletRef = null;

  wallets.forEach((doc) => {
    const txns = doc.data().transactions || [];

    if (txns.some((t) => t.id === requestId)) {
      userId = doc.id;
      walletRef = db.collection("wallets").doc(userId);
    }
  });

  if (!walletRef) {
    return res.json({
      data: {
        status: status || "PENDING",
        remark,
      },
    });
  }

  const walletDoc = await walletRef.get();
  const walletData = walletDoc.data();
  const transactions = walletData.transactions || [];

  const txn = transactions.find(
    (t) => t.id === requestId
  );

  if (!txn) {
    return res.json({
      data: {
        status: status || "PENDING",
        remark,
      },
    });
  }

  // ========================================================
  // SUCCESS
  // ========================================================
  if (
    status === "ORDER_COMPLETED" ||
    status === "200"
  ) {
    txn.status = "success";

    await walletRef.update({
      transactions,
    });

    return res.json({
      data: {
        status: "ORDER_COMPLETED",
        remark,
      },
    });
  }

  // ========================================================
  // FAILED
  // ========================================================
  if (
    status === "ORDER_FAILED" ||
    status === "FAILED"
  ) {
    txn.status = "failed";

    await walletRef.update({
      balance: walletData.balance + txn.amount,
      transactions:
        admin.firestore.FieldValue.arrayUnion({
          id: `${requestId}_refund`,
          type: "credit",
          title: `Refund: Airtime Purchase Failed (${txn.title})`,
          amount: txn.amount,
          timestamp: Date.now(),
          status: "refunded",
        }),
    });

    return res.json({
      data: {
        status: "ORDER_FAILED",
        remark,
      },
    });
  }

  // ========================================================
  // STILL PENDING
  // ========================================================
  return res.json({
    data: {
      status: status || "PENDING",
      remark,
    },
  });
});

// ============================================================
// Airtime Networks (ClubKonnect)
// ============================================================
app.get("/api/airtime/networks", async (req, res) => {
  try {
    const USER_ID = process.env.CLUBKONNECT_USERID;

    const url =
      `https://www.nellobytesystems.com/` +
      `APIAirtimeDiscountV2.asp?UserID=${USER_ID}`;

    const response = await axios.get(url);
    const raw = response.data;

    if (!raw?.MOBILE_NETWORK) {
      return res.status(400).json({
        status: false,
        message: "Invalid response from ClubKonnect",
        raw,
      });
    }

    const networks = {};
    const mobileNetworks = raw.MOBILE_NETWORK;

    for (const key in mobileNetworks) {
      const arr = mobileNetworks[key];

      if (!Array.isArray(arr) || arr.length === 0) {
        continue;
      }

      const item = arr[0];

      const name =
        item.PRODUCT_NAME ||
        item.network ||
        key
          .replace("m_", "")
          .replace("_", "")
          .trim();

      const code = item.ID;

      if (name && code) {
        networks[name] = code;
      }
    }

    return res.json({
      status: true,
      networks,
    });
  } catch (err) {
    console.error(
      "Airtime networks error:",
      err.message || err
    );

    return res.status(500).json({
      status: false,
      message: "Failed to fetch networks",
    });
  }
});

// ============================================================
// Save FCM Token
// ============================================================
app.post("/save-fcm-token", async (req, res) => {
  const { userId, token } = req.body;

  if (!userId || !token) {
    return res.status(400).json({
      status: false,
      message: "Missing userId or token",
    });
  }

  await db.collection("users").doc(userId).update({
    fcmToken: token,
  });

  return res.json({
    status: true,
    message: "Token saved",
  });
});

// ============================================================
// Start server
// ============================================================
app.listen(PORT, "0.0.0.0", () => {
  console.log(
    `UtilityHub backend running on http://0.0.0.0:${PORT}`
  );
});
